package com.lss.security.order.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(value = "spring-order")
@Component
public interface OrderFeignApi {
    @GetMapping(value = "/r1")
    String r1();
}
